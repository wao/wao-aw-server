import aw_server

aw_server.main()
